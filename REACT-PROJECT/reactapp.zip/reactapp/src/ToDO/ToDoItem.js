import React from "react";

export default function ToDoItem({todo}) {
    return(
        <li>{todo.title}</li>
    )
}